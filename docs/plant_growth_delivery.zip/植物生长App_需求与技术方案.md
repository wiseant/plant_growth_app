# 植物生长模拟 App — 需求与技术方案

> 目标平台：Android / iOS（Flutter）
> 文档版本：v1.0
> 最后更新：2026-09-07
> 配套代码：`plant_growth_json.zip`

---

## 目录

1. [需求概述](#1-需求概述)
2. [技术难点分析](#2-技术难点分析)
3. [方案选型与对比](#3-方案选型与对比)
4. [最终架构](#4-最终架构)
5. [数据契约：plants.json](#5-数据契约plantsjson)
6. [启动流程设计](#6-启动流程设计)
7. [抽帧服务：不卡顿的七个设计](#7-抽帧服务不卡顿的七个设计)
8. [视频素材规范](#8-视频素材规范)
9. [工程结构与代码清单](#9-工程结构与代码清单)
10. [新增一种植物的完整流程](#10-新增一种植物的完整流程)
11. [风险清单与兜底方案](#11-风险清单与兜底方案)
12. [给 CodeBuddy 的落地任务清单](#12-给-codebuddy-的落地任务清单)
13. [附录：实测数据](#13-附录实测数据)

---

## 1. 需求概述

### 1.1 功能需求

| 编号 | 需求 | 说明 |
|:---:|---|---|
| FR-1 | 植物列表页 | 展示若干种植物的**成熟形态照片**，网格布局 |
| FR-2 | 生长模拟页 | 点击进入，显示当前生长阶段的画面 + 天数进度 |
| FR-3 | 生长交互 | 页面提供【生长】按钮，**每点一次植物长大一天** |
| FR-4 | 成熟态 | 生长到周期末显示【播放动画】按钮 |
| FR-5 | 动画播放 | 点击【播放动画】播放该植物对应的完整 mp4 |
| FR-6 | 差异化周期 | 不同植物生长周期不同，**最短 7 天，最长 300 天**，定义在种子数据中 |

### 1.2 非功能需求

| 编号 | 需求 | 指标 |
|:---:|---|---|
| NFR-1 | 流畅性 | 点击【生长】无卡顿、无白屏、无闪黑 |
| NFR-2 | 双端一致 | Android / iOS 行为与画面一致 |
| NFR-3 | 可扩展性 | 新增植物**不改动 Dart 代码**、不重新发版 |
| NFR-4 | 包体积 | 视频走 CDN 下载，不打入安装包 |
| NFR-5 | 离线可用 | 资源下载完成后，弱网/离线可正常使用 |

---

## 2. 技术难点分析

需求拆解后只有三个环节：

| 环节 | 难度 | 说明 |
|---|:---:|---|
| 列表页成熟照片 | 低 | 每种植物 1 张静态图 |
| **生长页"第 N 天的画面"** | **高** | 唯一的技术分水岭 |
| 成熟后播放 mp4 | 低 | `video_player` 直接实现 |

**所有方案的差异，本质是"第 N 天的画面从哪来"** —— 其余 80% 代码是共用的。

### 2.1 核心矛盾

- 画面来自 mp4 视频，但用户交互是**离散的、随机的**（想点哪天点哪天）
- 视频 seek 是**异步的**（50~300ms），不可能同步响应点击
- 300 天周期的植物，若每天一帧，数据量与抽帧开销都很大

### 2.2 关键约束

- `video_thumbnail` / `MediaMetadataRetriever` 等原生 API **读不了 Flutter assets**，必须先把视频落到沙盒文件系统
- 移动端**硬件解码器数量有限**，并发抽帧过多会崩溃
- iOS 上 libwebp 编码 WebP 有明显性能问题（官方 README 已注明）

---

## 3. 方案选型与对比

### 3.1 四种候选方案

#### 方案 A：离线预导出帧序列

构建期用 ffmpeg 把每个 mp4 抽成 N 张 WebP，App 按 index 读图。

```
tomato.mp4  ──ffmpeg──▶  assets/plants/tomato/
                          ├─ cover.webp
                          ├─ manifest.json
                          └─ frames/0001.webp ... 0090.webp
```

- ✅ 运行时零解码成本、零平台差异、点击零延迟
- ❌ **新增植物必须重跑构建脚本 + 重新生成 pubspec asset 列表 + 发版**

#### 方案 B：运行时原生抽帧 + 磁盘缓存 ✅ **选定**

App 里按需 `day → 时间戳 → 抽帧 → 落盘缓存`。

- ✅ 安装包增量极小；视频内容可随时替换
- ✅ 新增植物只需改配置
- ⚠️ 需处理并发、预取、缓存管理

#### 方案 C：雪碧图（图集）

```bash
ffmpeg -i in.mp4 -vf "fps=10,scale=160:-2,tile=10x12" -frames:v 1 -c:v libwebp -q 80 sheet.webp
```

- ✅ 一次解码、零 IO
- ❌ **整图解经常驻内存**（1600×1080 = 6.9MB），300 帧方案内存爆炸；仅适合 7~30 天

#### 方案 D：隐藏播放器 seek 冻结

用不可见 `video_player` seek 到 t 后 pause，把 texture 当静态图。

- ❌ `seekTo` 异步，快速连点必然错帧
- ❌ 默认只对齐关键帧，帧不精确
- ❌ 第 N 天与播放动画抢同一播放器实例

### 3.2 横向对比

| 维度 | A 离线帧序列 | **B 运行时抽帧** | C 雪碧图 | D seek 冻结 |
|---|:---:|:---:|:---:|:---:|
| 安装包增量 | 中（可控） | **极小** | 小 | 极小 |
| 点击响应 | 0 ms | **冷 50~300ms / 热 0ms** | 0 ms | 50~200 ms |
| 帧精度 | 完全一致 | 一致 | 一致 | 差（关键帧对齐） |
| 双端一致性 | 100% | **需一次调校** | 100% | 差 |
| 内存占用 | 低 | 低 | **高** | 中 |
| **内容热更新** | ❌ 需发版 | **✅ 改配置即可** | ❌ | ✅ |
| 实现复杂度 | 低（+构建脚本） | 中 | 中 | 低但坑多 |
| 300 天长周期 | ✅ | ✅ | ❌ | ✅ |

### 3.3 抽帧库选型：`video_thumbnail` vs `media_kit`

| 对比项 | `video_thumbnail` | `media_kit` |
|---|---|---|
| 定位 | **纯缩略图抽取** | 完整播放器（libmpv） |
| 底层 | Android `MediaMetadataRetriever`<br>iOS `AVAssetImageGenerator` | libmpv + FFmpeg |
| 平台支持 | **Android + iOS** | 全平台（含桌面/Web） |
| 包体积 | **几乎为 0** | APK +50~150MB（社区实测） |
| 抽帧 API | `thumbnailFile(video, thumbnailPath, timeMs, maxWidth, quality)` | `player.screenshot()` |
| **是否自动磁盘缓存** | **否，需自行落盘**（用 `thumbnailFile` 指定路径即可） | **否，返回内存字节，需自行写文件** |
| 双端一致性 | **统一 Dart API，内部双端各自实现** | 同一 libmpv，天然一致 |
| 已知问题 | iOS WebP 编码慢（用 JPEG 规避） | `screenshot()` 存在初始化竞态，需等待 idle-active |

**结论**：两者**都不会自动做磁盘缓存**，都返回内存数据或写到指定路径。本需求只需抽帧、不需要播放器能力（`video_player` 已足够），**`video_thumbnail` 是明确更优解** —— 零包体积代价、API 简单、双端统一。

> ⚠️ **不要使用 `ffmpeg_kit_flutter`**：FFmpegKit 已官宣退役，2025-04-01 起 Maven Central / CocoaPods 二进制全部下架。

---

## 4. 最终架构

### 4.1 整体分层

```
┌─────────────────────────────────────────────────────┐
│  UI 层                                               │
│  SplashPage（下载进度）                                │
│  PlantListPage（成熟照片网格）                          │
│  PlantGrowthPage（生长模拟 + 播放动画）                 │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│  服务层                                               │
│  PlantRepository        配置加载（本地打底+远程覆盖）   │
│  ResourceDownloader     资源下载 + 进度 + 坏缓存校验   │
│  PlantFrameService      抽帧缓存 + 预取 + 时长探测     │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│  能力层（原生）                                        │
│  video_thumbnail   抽帧（可替换为自研 Channel）         │
│  video_player      播放动画 + 时长探测                 │
│  flutter_cache_manager  磁盘缓存                      │
└─────────────────────────────────────────────────────┘
```

### 4.2 抽帧器可替换设计

抽帧能力抽象为接口，未来若 `video_thumbnail` 在某机型失效，只需替换实现类，其余代码零改动：

```dart
abstract class FrameExtractor {
  Future<String?> extract({
    required String videoFile,
    required String outputFile,
    required int timeMs,
    required int maxWidth,
  });
}

class VideoThumbnailExtractor implements FrameExtractor { /* video_thumbnail 实现 */ }
// class NativeChannelExtractor implements FrameExtractor { /* 自研 Channel 兜底 */ }
```

---

## 5. 数据契约：plants.json

### 5.1 完整字段

| 字段 | 类型 | 必填 | 说明 |
|---|:---:|:---:|---|
| `id` | string | ✅ | 唯一标识，用作缓存 key |
| `name` | string | ✅ | 展示名 |
| `totalDays` | int | ✅ | 生长周期天数（7~300） |
| `videoUrl` | string | ✅ | mp4 下载地址 |
| `videoDurationMs` | int | ❌ | **可省略**，省略则由 App 运行时探测一次并持久化 |
| `sampleCount` | int | ❌ | 实际抽帧数，默认 = `totalDays` |
| `frameWidth` | int | ❌ | 抽帧宽度，默认 720 |
| `coverUrl` | string | ❌ | 成熟封面图，给了可省一次抽帧 |

顶层另有 `version`（配置版本号，预留）。

### 5.2 示例

```json
{
  "version": 1,
  "plants": [
    {
      "id": "bean",
      "name": "绿豆芽",
      "totalDays": 7,
      "videoUrl": "https://cdn.example.com/plants/bean.mp4",
      "videoDurationMs": 10500,
      "sampleCount": 7,
      "frameWidth": 720
    },
    {
      "id": "sunflower",
      "name": "向日葵",
      "totalDays": 90,
      "videoUrl": "https://cdn.example.com/plants/sunflower.mp4",
      "videoDurationMs": 18200,
      "sampleCount": 90,
      "frameWidth": 720,
      "coverUrl": "https://cdn.example.com/plants/sunflower_cover.jpg"
    },
    {
      "id": "tomato",
      "name": "番茄",
      "totalDays": 120,
      "videoUrl": "https://cdn.example.com/plants/tomato.mp4",
      "sampleCount": 120,
      "frameWidth": 720
    },
    {
      "id": "oak",
      "name": "橡树",
      "totalDays": 300,
      "videoUrl": "https://cdn.example.com/plants/oak.mp4",
      "sampleCount": 120,
      "frameWidth": 512
    }
  ]
}
```

### 5.3 长周期降采样

300 天的植物**不必抽 300 帧**。设 `sampleCount: 120`，相邻天共用同一帧，肉眼无差别但缓存命中率显著提高、磁盘占用减半。

映射公式（`PlantSpecies`）：

```dart
int frameIndexForDay(int day) {
  final n = effectiveSampleCount;
  if (n <= 1 || totalDays <= 1) return 0;
  final t = (day - 1) / (totalDays - 1);
  return (t * (n - 1)).round().clamp(0, n - 1);
}

int timeMsForDay(int day, int durationMs) {
  final idx = frameIndexForDay(day);
  final n = effectiveSampleCount;
  if (n <= 1) return 0;
  // 收 1ms，避免 seek 到视频绝对末尾时原生侧返回 null
  return (idx / (n - 1) * durationMs).round().clamp(0, durationMs - 1);
}
```

---

## 6. 启动流程设计

### 6.1 流程图

```
main()
  │
  ├─ ① 加载配置
  │     assets/plants/plants.json（必成，离线保底）
  │     └─ 若配了 kRemoteConfigUrl → 拉远程覆盖（4s 超时，失败静默回退本地）
  │
  ├─ ② ResourceDownloader.start()
  │     ├─ 逐个查本地缓存 ─ 命中且健康 → 直接登记，零流量
  │     ├─ 未命中 / 坏缓存 → 并发 3 路下载
  │     └─ 广播进度流 → SplashPage 渲染进度条
  │
  ├─ ③ registerVideos()  把本地路径交给抽帧服务
  │
  ├─ ④ pushReplacement → PlantListPage
  │
  └─ ⑤ 后台 warmUpDurations()  预热视频时长（不阻塞首屏）
```

### 6.2 进度条呈现

```
              🌱
        正在准备植物资源

    ▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░
        62%  5/8  ·  番茄
```

下载失败（必需资源）→ 停留错误页 + 【重试】按钮。封面图属非必需，失败不阻塞。

### 6.3 配置加载策略

**本地 assets 打底 + 远程 JSON 覆盖**：

- 本地必成 —— 保证首次启动、离线状态一定可用
- 远程超时 4s 自动放弃 —— 不拖慢启动
- 远程失败静默回退本地 —— 用户无感知

这样"新增植物"只需改服务器 JSON，用户下次启动自动拉到，**不用发版**。

### 6.4 缓存健康校验

下载前校验 mp4 头部魔数：

```dart
// mp4 结构: [4字节 size][ftyp]...
String.fromCharCodes(head.sublist(4, 8)) == 'ftyp'
```

下载中断留下的**截断文件**会被识别并清掉重下 —— 否则会卡在"植物页一直白屏"。

> 封面图只校验非空，**不校验魔数**（格式可能是 jpg/png/webp，用 mp4 校验会误判为坏文件，导致每次启动反复重下）。

---

## 7. 抽帧服务：不卡顿的七个设计

### 7.1 请求路径

```
点击【生长】
   │
   ├─▶ peek(): File.existsSync()   ← 同步、微秒级
   │      │
   │      ├─ 命中 ──▶ 直接 setState 换路径，零抽帧、零等待 ✅
   │      │
   │      └─ 未命中 ─▶ 保留上一帧不闪黑 → 后台抽 → 抽好再切
   │                    （同时预取 N+1..N+4）
   ▼
下一次点击时，N+1 已经在磁盘上了
```

### 7.2 七条措施

| # | 措施 | 解决什么 |
|:---:|---|---|
| 1 | **用 `thumbnailFile` 不用 `thumbnailData`** | 避免大字节数组跨 Platform Channel 拷贝 |
| 2 | **`peek()` 同步判断** | 命中路径微秒级，点击真正零延迟 |
| 3 | **预取后 4 天** | 用户看第 N 天时，N+1 已落盘，永远命中 |
| 4 | **`cacheWidth: 720`** | 按显示宽度解码，省一半内存与解码时间 |
| 5 | **并发闸门限制 2 个** | 移动端硬件解码器数量有限，开多了会崩 |
| 6 | **同 key 请求合并** | 长按连点时不会重复抽同一帧 |
| 7 | **采样降频** | 300 天只抽 120 帧，命中率更高 |

### 7.3 UI 层防闪黑

```dart
AnimatedSwitcher(
  duration: const Duration(milliseconds: 200),
  child: Image.file(
    File(path),
    key: ValueKey(path),
    gaplessPlayback: true,      // 换帧不闪黑
    cacheWidth: plant.frameWidth,
    fit: BoxFit.contain,
  ),
)
```

未命中时**保留上一帧做占位**，抽好再切 —— 用户看到的是 200ms 淡入淡出，而非白屏。

### 7.4 长按连续生长

300 天的植物不可能让用户点 300 次：

```dart
onLongPressStart: (_) => _autoTimer =
    Timer.periodic(const Duration(milliseconds: 80), (_) => _grow()),
onLongPressEnd: (_) => _autoTimer?.cancel(),
```

### 7.5 ⚠️ 不要给抽帧套 Isolate

耗时全在 **native 层**（原生解码器），Dart 侧本来就异步。套 Isolate 只会徒增字节数组跨 isolate 拷贝的开销，**净亏损**。

---

## 8. 视频素材规范

### 8.1 推荐编码参数

```bash
ffmpeg -i input.mp4 \
  -c:v libx264 -profile:v main -pix_fmt yuv420p \
  -g 30 -movflags +faststart -an \
  output.mp4
```

| 参数 | 作用 |
|---|---|
| `-profile:v main` | 兼容性最好 |
| `-pix_fmt yuv420p` | **必须**，否则部分机型解码异常 |
| `-g 30` | 关键帧间隔，见 8.2 |
| `-movflags +faststart` | moov 前置，避免 seek 卡顿 |
| `-an` | 去掉无用音轨 |

### 8.2 ⚠️ 关键帧间隔：不要用 `-g 1`

早期建议的全 I 帧（`-g 1`）代价过大，**已修正**。实测 12 秒 640×360 测试片：

| GOP | 体积 | 相对默认 |
|---|---:|---:|
| 默认（`-g 250`） | 79 KB | 1.0× |
| `-g 60` | 100 KB | 1.3× |
| **`-g 30`** | **130 KB** | **1.6×** ← 推荐 |
| `-g 12` | 206 KB | 2.6× |
| `-g 6` | 326 KB | 4.1× |
| `-g 1` | 1390 KB | **17.6×** ❌ |

**全 I 帧让体积涨 17 倍**，10 段视频就是几十上百 MB，不可接受。

### 8.3 是否需要重编码？

**大多数情况不需要**，直接把原始 mp4 用起来：

- **iOS** `AVAssetImageGenerator` 逐帧解码，精度与 GOP 无关
- **Android** `getFrameAtTime(t, OPTION_CLOSEST)` 也能拿到非关键帧，GOP 只影响速度

只有出现这个现象才需要重编码：

> **连续点几天画面完全一样，但过几帧突然跳一大截** —— 说明只抽到了关键帧。

此时用 `-g 30` 即可（体积仅 +1.6 倍）。

---

## 9. 工程结构与代码清单

```
plant_growth/
├── pubspec.yaml
├── assets/plants/plants.json        ← 本地种子配置（离线保底）
└── lib/
    ├── main.dart                    ← 入口 + 启动下载页（进度条）
    ├── models/plant_species.dart    ← 数据模型 + JSON 解析
    ├── services/
    │   ├── plant_repository.dart    ← 配置加载（本地打底 + 远程覆盖）
    │   ├── resource_downloader.dart ← 资源下载 + 进度 + 坏缓存校验
    │   └── plant_frame_service.dart ← 抽帧缓存 + 预取 + 时长探测
    └── pages/
        ├── plant_list_page.dart     ← 成熟照片网格
        └── growth_page.dart         ← 生长模拟 + 播放动画
```

### 9.1 依赖

```yaml
dependencies:
  flutter:
    sdk: flutter
  video_thumbnail: ^0.5.6        # 抽帧
  video_player: ^2.9.1           # 播放动画 + 时长探测
  flutter_cache_manager: ^3.4.1  # 资源下载与磁盘缓存
  http: ^1.2.2                   # 远程配置拉取
  path: ^1.9.0
  path_provider: ^2.1.4
```

### 9.2 关键类速查

| 类 | 职责 | 关键方法 |
|---|---|---|
| `PlantSpecies` | 数据模型 + 天数↔时间映射 | `frameIndexForDay` / `timeMsForDay` / `fromJson` |
| `PlantRepository` | 配置加载 | `load()` / `loadLocal()` |
| `ResourceDownloader` | 下载 + 进度 | `start()` / `progress` 流 / `videoPaths` |
| `PlantFrameService` | 抽帧缓存 | `peek()` / `frameFor()` / `prefetch()` / `warmUp()` |
| `FrameExtractor` | 抽帧能力抽象（可替换） | `extract()` |

### 9.3 需要改动的两处

1. `lib/main.dart` 第 12 行：`kRemoteConfigUrl` 填你的配置地址（不想远程就留 `null`，纯本地模式）
2. `assets/plants/plants.json`：换成真实 CDN 地址与植物数据

---

## 10. 新增一种植物的完整流程

### 10.1 远程模式（推荐，已配置 `kRemoteConfigUrl`）

```
1. 把 mp4 传到 CDN
2. 服务器 plants.json 加一条记录
```

**Dart 代码一行不用改，ffmpeg 一次不用跑，不用发版。**

### 10.2 本地模式（`kRemoteConfigUrl = null`）

```
1. assets/plants/plants.json 加一条记录
2. 发版
```

### 10.3 何时才需要动 ffmpeg

仅当发现"连续几天画面重复"时，在**服务端**重编码：

```bash
ffmpeg -i oak.mp4 -c:v libx264 -g 30 -profile:v main \
       -pix_fmt yuv420p -movflags +faststart -an oak.mp4
```

> 视频改为远程下载后，本地重编码环节已从常规流程中消失。

---

## 11. 风险清单与兜底方案

| # | 风险 | 影响 | 应对 |
|:---:|---|---|---|
| 1 | `video_thumbnail` 某机型失效 | 抽帧返回 null，画面不更新 | 实现 `NativeChannelExtractor` 替换（见 11.1） |
| 2 | 下载中断留下截断文件 | 白屏或播放失败 | 已实现 `ftyp` 魔数校验，自动清缓存重下 |
| 3 | 视频 URL 替换后帧缓存未更新 | 显示旧画面 | 帧文件名含 URL 摘要（djb2），自动失效 |
| 4 | 缓存目录持续增长 | 占用存储 | 列表页提供【清理抽帧缓存】，10 种植物约 72MB |
| 5 | 300 天需点击 300 次 | 体验差 | 长按连续生长（80ms/天） |
| 6 | 首次抽帧等待 | 首次点击有延迟 | `warmUp()` 预热第 1 天与成熟帧 + 预取后 4 天 |
| 7 | iOS 模拟器性能差异大 | 误判性能 | **必须真机测试** |
| 8 | 播放页与抽帧抢解码器 | 异常 | 播放用独立 `VideoPlayerController`，懒加载 |

### 11.1 兜底：自研 Platform Channel 抽帧

若 `video_thumbnail` 大面积失效，实现同一个 `FrameExtractor` 接口即可，其余代码零改动。

**Android**（`MediaMetadataRetriever`）：

```kotlin
val retriever = MediaMetadataRetriever()
retriever.setDataSource(videoPath)
// OPTION_CLOSEST 才能拿非关键帧；OPTION_CLOSEST_SYNC 只能拿关键帧
val bmp = retriever.getFrameAtTime(timeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
bmp?.compress(Bitmap.CompressFormat.JPEG, 88, FileOutputStream(outFile))
retriever.release()
```

**iOS**（`AVAssetImageGenerator`）：

```swift
let asset = AVAsset(url: URL(fileURLWithPath: videoPath))
let gen = AVAssetImageGenerator(asset: asset)
gen.appliesPreferredTrackTransform = true   // 必须，否则旋转/变形
gen.requestedTimeToleranceBefore = .zero   // 帧级精度
gen.requestedTimeToleranceAfter  = .zero
let cg = try gen.copyCGImage(at: CMTime(value: Int64(timeMs), timescale: 1000), actualTime: nil)
let data = UIImage(cgImage: cg).jpegData(compressionQuality: 0.88)
try data?.write(to: URL(fileURLWithPath: outFile))
```

---

## 12. 给 CodeBuddy 的落地任务清单

> 建议在 Android Studio 中按下列顺序交付，每步可独立验证。

### 阶段一：工程跑起来

- [ ] `flutter create plant_growth`，按 9.1 配置 `pubspec.yaml`，`flutter pub get`
- [ ] 放入 `assets/plants/plants.json`（先用 1~2 种植物、真实可访问的 CDN 地址）
- [ ] 拷贝 `models/` 与 `services/` 三个文件，`flutter analyze` 通过
- [ ] `main.dart` 先设 `kRemoteConfigUrl = null`（本地模式），跑通启动下载页

**验收**：看到进度条走完 → 进入列表页 → 能看到封面图。

### 阶段二：生长交互

- [ ] 接入 `pages/plant_list_page.dart` 与 `pages/growth_page.dart`
- [ ] 点击【生长】验证：首几次点击可能有短暂等待，之后应**瞬时切换**
- [ ] 长按验证连续生长；300 天植物长按约 24s 走完
- [ ] 成熟后【播放动画】能正常播放

**验收**：连续点击 20 次无卡顿、无白屏、无闪黑。

### 阶段三：双端调试

- [ ] **iOS 真机**验证抽帧耗时与画面正确性
- [ ] **Android 低端机**验证并发闸门是否触发、内存是否平稳
- [ ] 用 DevTools Performance 面板确认点击路径无掉帧

**验收**：两端各抽 30 帧，比对画面与耗时。

### 阶段四：上架前

- [ ] 配置 `kRemoteConfigUrl`，验证远程覆盖与超时回退
- [ ] 加 `shared_preferences` 持久化每种植物当前生长天数（可选）
- [ ] 设置页接入 `clearFrames()` 与缓存大小显示
- [ ] 检查 iOS 蜂窝下载 200MB / Android AAB 200MB 限制

### 调试要点

| 现象 | 排查方向 |
|---|---|
| 列表页封面一直转圈 | 视频未下载成功 / `ftyp` 校验失败 / `videoUrl` 不可达 |
| 生长页空白 | `registerVideos` 未调用 / 抽帧返回 null（看 logcat 的 `[FrameExtractor]`） |
| 连续几天画面一样 | GOP 过大，需 `-g 30` 重编码 |
| 快速连点卡死 | 并发闸门是否生效 / 预取是否触发 |
| iOS 抽帧极慢 | 确认用的是 JPEG 而非 WebP |

---

## 13. 附录：实测数据

测试环境：沙盒 ffmpeg 4.4.2，测试片 12 秒 / 1280×720 / 30fps（噪点最大的 `testsrc`，实际植物视频压缩率会明显更好）。

### 13.1 抽帧体积（供方案 A 参考）

| 配置 | 帧数 | 总大小 | 单帧均值 |
|---|---:|---:|---:|
| 512px / WebP q78 | 150 | 646 KB | 4.3 KB |
| 720px / WebP q78 | 150 | 751 KB | 5.0 KB |

按此估算，10 种植物 512px 方案约 6.5 MB（方案 A 全量打包场景）。

### 13.2 雪碧图（供方案 C 参考）

10×12 = 120 格、每格 160px → 图集 1600×1080，**总大小 162 KB**。
但解码后常驻内存 = 1600 × 1080 × 4B ≈ **6.9 MB**，长周期不可用。

### 13.3 封面抽取

| 方式 | 产物 | 大小 |
|---|---|---:|
| `-sseof -0.05`（会偏几帧） | 1280×720 WebP q85 | 11.0 KB |
| `select=eq(n\,LAST)`（精确末帧） | 720×406 WebP q85 | 7.0 KB |

**推荐精确末帧写法**：

```bash
NB=$(ffprobe -v error -count_frames -select_streams v:0 \
     -show_entries stream=nb_read_frames -of csv=p=0 in.mp4)
LAST=$((NB - 1))
ffmpeg -i in.mp4 -vf "select=eq(n\,$LAST),scale=720:-2" \
       -vsync 0 -frames:v 1 -c:v libwebp -quality 85 cover.webp
```

### 13.4 GOP 体积对照

见 [8.2 节](#82--关键帧间隔不要用--g-1)。

---

## 变更记录

| 版本 | 日期 | 说明 |
|:---:|---|---|
| v1.0 | 2026-09-07 | 初版。方案 A→B 切换，改为 JSON 驱动 + 远程可更新 + 启动下载 |
