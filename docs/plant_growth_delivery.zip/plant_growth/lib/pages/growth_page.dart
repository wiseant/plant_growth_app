import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../models/plant_species.dart';
import '../services/plant_frame_service.dart';

/// 生长页：每点一次[生长]长大一天，成熟后显示[播放动画]
class PlantGrowthPage extends StatefulWidget {
  const PlantGrowthPage({super.key, required this.plant, required this.service});

  final PlantSpecies plant;
  final PlantFrameService service;

  @override
  State<PlantGrowthPage> createState() => _PlantGrowthPageState();
}

class _PlantGrowthPageState extends State<PlantGrowthPage> {
  int _day = 1;
  String? _framePath;
  Timer? _autoTimer;
  bool _busy = true;

  PlantSpecies get plant => widget.plant;
  bool get isMature => _day >= plant.totalDays;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    // 首帧必须等出来，否则进入页面会空白
    final first = await widget.service.frameFor(plant, 1);
    if (!mounted) return;
    setState(() {
      _framePath = first;
      _busy = false;
    });
    // 后台把成熟帧 + 后续几天备好
    unawaited(widget.service.warmUp(plant));
    widget.service.prefetch(plant, _day);
  }

  void _grow() {
    if (isMature || _busy) return;
    setState(() => _day++);
    _resolveFrame();
  }

  Future<void> _resolveFrame() async {
    final day = _day;

    // 同步命中：直接切，一帧都不掉
    final hit = widget.service.peek(plant, day);
    if (hit != null) {
      if (!mounted || _day != day) return;
      setState(() => _framePath = hit);
      widget.service.prefetch(plant, day);
      return;
    }

    // 未命中：保留上一帧做占位（不闪黑），抽好再切
    final path = await widget.service.frameFor(plant, day);
    if (!mounted || _day != day || path == null) return;
    setState(() => _framePath = path);
    widget.service.prefetch(plant, day);
  }

  void _reset() {
    _autoTimer?.cancel();
    setState(() => _day = 1);
    _resolveFrame();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(plant.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.restart_alt),
            tooltip: '重新生长',
            onPressed: _reset,
          ),
        ],
      ),
      body: Column(
        children: [
          LinearProgressIndicator(value: _day / plant.totalDays),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(
              children: [
                Text('第 $_day / ${plant.totalDays} 天',
                    style: Theme.of(context).textTheme.titleMedium),
                const Spacer(),
                Text('${(_day / plant.totalDays * 100).toStringAsFixed(0)}%',
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          Expanded(child: _buildStage()),
          Padding(
            padding: const EdgeInsets.all(24),
            child: isMature
                ? _PlayAnimationButton(
                    localPath: widget.service.localVideo(plant.id),
                    fallbackUrl: plant.videoUrl,
                  )
                : _buildGrowButton(),
          ),
        ],
      ),
    );
  }

  Widget _buildStage() {
    final path = _framePath;
    if (path == null) return const Center(child: CircularProgressIndicator());

    // AnimatedSwitcher + gaplessPlayback：换帧淡入淡出，绝不闪黑
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      switchInCurve: Curves.easeOut,
      child: Image.file(
        File(path),
        key: ValueKey(path),
        fit: BoxFit.contain,
        gaplessPlayback: true,
        // 按显示宽度解码，别解 1080p 原图（一张就 8MB 内存）
        cacheWidth: plant.frameWidth,
        filterQuality: FilterQuality.medium,
        errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, size: 64),
      ),
    );
  }

  Widget _buildGrowButton() {
    return GestureDetector(
      // 长按连续生长：300 天的植物不可能让用户点 300 次
      onLongPressStart: (_) => _autoTimer =
          Timer.periodic(const Duration(milliseconds: 80), (_) => _grow()),
      onLongPressEnd: (_) => _autoTimer?.cancel(),
      onLongPressCancel: () => _autoTimer?.cancel(),
      child: FilledButton.icon(
        icon: const Icon(Icons.trending_up),
        label: const Text('生长'),
        onPressed: _grow,
      ),
    );
  }

  @override
  void dispose() {
    _autoTimer?.cancel();
    super.dispose();
  }
}

// ===========================================================================

/// 成熟后的动画播放按钮。播放用 video_player，与抽帧解耦。
class _PlayAnimationButton extends StatefulWidget {
  const _PlayAnimationButton({required this.localPath, required this.fallbackUrl});

  /// 本地缓存路径。为 null 或文件不存在时回退到网络地址。
  final String? localPath;
  final String fallbackUrl;

  @override
  State<_PlayAnimationButton> createState() => _PlayAnimationButtonState();
}

class _PlayAnimationButtonState extends State<_PlayAnimationButton> {
  VideoPlayerController? _vc;

  Future<void> _play() async {
    // 懒加载：只有真要播时才初始化播放器
    _vc ??= _createController();
    final vc = _vc!;
    if (!vc.value.isInitialized) {
      await vc.initialize();
    }
    if (!mounted) return;

    await vc.seekTo(Duration.zero);
    await vc.play();

    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => _FullscreenVideo(controller: vc),
        fullscreenDialog: true,
      ),
    );
    await vc.pause();
  }

  VideoPlayerController _createController() {
    final local = widget.localPath;
    if (local != null && File(local).existsSync()) {
      return VideoPlayerController.file(File(local));
    }
    return VideoPlayerController.networkUrl(Uri.parse(widget.fallbackUrl));
  }

  @override
  Widget build(BuildContext context) => FilledButton.icon(
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        icon: const Icon(Icons.play_circle_fill),
        label: const Text('播放生长动画'),
        onPressed: _play,
      );

  @override
  void dispose() {
    _vc?.dispose();
    super.dispose();
  }
}

class _FullscreenVideo extends StatelessWidget {
  const _FullscreenVideo({required this.controller});
  final VideoPlayerController controller;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          alignment: Alignment.center,
          children: [
            AspectRatio(
              aspectRatio: controller.value.aspectRatio,
              child: VideoPlayer(controller),
            ),
            Positioned(
              top: 48,
              right: 16,
              child: IconButton.filledTonal(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
          ],
        ),
      );
}
