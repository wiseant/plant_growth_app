import 'dart:io';

import 'package:flutter/material.dart';

import '../models/plant_species.dart';
import '../services/plant_frame_service.dart';
import 'growth_page.dart';

/// 列表页：展示各种植物的成熟形态照片
///
/// 封面来源优先级：
///   1. JSON 里配了 coverUrl 且已下载  -> 直接用（最快）
///   2. 否则抽视频最后一帧            -> 与生长页共用同一份帧缓存
class PlantListPage extends StatefulWidget {
  const PlantListPage({
    super.key,
    required this.plants,
    required this.service,
    required this.coverPaths,
  });

  final List<PlantSpecies> plants;
  final PlantFrameService service;
  final Map<String, String> coverPaths;

  @override
  State<PlantListPage> createState() => _PlantListPageState();
}

class _PlantListPageState extends State<PlantListPage> {
  /// plantId -> 最终要显示的本地图片路径
  final Map<String, String?> _covers = {};

  @override
  void initState() {
    super.initState();
    _resolveCovers();
  }

  Future<void> _resolveCovers() async {
    for (final plant in widget.plants) {
      // 优先用已下载的封面图
      final cover = widget.coverPaths[plant.id];
      if (cover != null) {
        if (mounted) setState(() => _covers[plant.id] = cover);
        continue;
      }
      // 否则抽最后一帧（成熟形态）
      final path = await widget.service.frameFor(plant, plant.totalDays);
      if (mounted) setState(() => _covers[plant.id] = path);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('植物图鉴'),
        actions: [
          IconButton(
            icon: const Icon(Icons.cleaning_services_outlined),
            tooltip: '清理抽帧缓存',
            onPressed: () async {
              final n = await widget.service.clearFrames();
              if (!mounted) return;
              setState(() => _covers.clear());
              _resolveCovers();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('已清理 $n 张缓存帧')),
              );
            },
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.82,
        ),
        itemCount: widget.plants.length,
        itemBuilder: (context, i) {
          final plant = widget.plants[i];
          final cover = _covers[plant.id];
          return Card(
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => PlantGrowthPage(plant: plant, service: widget.service),
              )),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: cover == null
                        ? const Center(child: CircularProgressIndicator())
                        : Image.file(
                            File(cover),
                            fit: BoxFit.cover,
                            cacheWidth: 400,
                            gaplessPlayback: true,
                            errorBuilder: (_, __, ___) =>
                                const Icon(Icons.broken_image, size: 48),
                          ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(plant.name,
                            style: Theme.of(context).textTheme.titleSmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 2),
                        Text('${plant.totalDays} 天',
                            style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
