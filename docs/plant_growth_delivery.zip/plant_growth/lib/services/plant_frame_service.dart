import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

import '../models/plant_species.dart';

// ===========================================================================
// 1) 抽帧器抽象层 —— 换实现只需替换这里
// ===========================================================================

abstract class FrameExtractor {
  Future<String?> extract({
    required String videoFile,
    required String outputFile,
    required int timeMs,
    required int maxWidth,
  });
}

/// 基于 video_thumbnail 的实现（推荐）
///
/// 关键点：用 **thumbnailFile** 而非 thumbnailData —— 让原生侧直接写文件，
/// 避免大字节数组跨 Platform Channel 拷贝，这是不卡顿的第一要素。
class VideoThumbnailExtractor implements FrameExtractor {
  const VideoThumbnailExtractor({this.quality = 88});

  /// 双端统一用 JPEG：iOS 上 libwebp 编码 WebP 有明显性能问题。
  final int quality;

  @override
  Future<String?> extract({
    required String videoFile,
    required String outputFile,
    required int timeMs,
    required int maxWidth,
  }) async {
    try {
      return await VideoThumbnail.thumbnailFile(
        video: videoFile,
        thumbnailPath: outputFile,
        imageFormat: ImageFormat.JPEG,
        maxWidth: maxWidth,
        timeMs: timeMs,
        quality: quality,
      );
    } catch (e, st) {
      debugPrint('[FrameExtractor] 抽帧失败 $videoFile@${timeMs}ms: $e\n$st');
      return null;
    }
  }
}

// ===========================================================================
// 2) 并发闸门 —— 防止同时开太多 native 解码器
// ===========================================================================

class _Gate {
  _Gate(this.limit);
  final int limit;
  int _running = 0;
  final List<Completer<void>> _waiters = [];

  Future<T> run<T>(Future<T> Function() task) async {
    if (_running >= limit) {
      final c = Completer<void>();
      _waiters.add(c);
      await c.future;
    }
    _running++;
    try {
      return await task();
    } finally {
      _running--;
      if (_waiters.isNotEmpty) _waiters.removeAt(0).complete();
    }
  }
}

// ===========================================================================
// 3) 帧缓存服务
// ===========================================================================

class PlantFrameService {
  PlantFrameService._(this._extractor, this._root, this._durations, this._durationsFile);

  final FrameExtractor _extractor;
  final Directory _root;

  /// 运行时探测到的视频时长缓存（并持久化到 durations.json）
  final Map<String, int> _durations;
  final File _durationsFile;

  /// plantId -> 本地视频路径（由 ResourceDownloader 下载后注册）
  final Map<String, String> _videoPaths = {};

  /// 同一个 key 的并发请求合并，避免重复抽帧
  final Map<String, Future<String?>> _inflight = {};

  /// 并发闸门：移动端硬件解码器数量有限，同时最多 2 个抽帧任务
  final _gate = _Gate(2);

  static PlantFrameService? _instance;

  static Future<PlantFrameService> instance([FrameExtractor? extractor]) async {
    if (_instance != null) return _instance!;
    final doc = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(doc.path, 'plant_frames'));
    if (!root.existsSync()) root.createSync(recursive: true);

    final durFile = File(p.join(root.path, 'durations.json'));
    Map<String, int> durations = {};
    if (durFile.existsSync()) {
      try {
        final m = json.decode(await durFile.readAsString()) as Map<String, dynamic>;
        durations = m.map((k, v) => MapEntry(k, v as int));
      } catch (_) {
        durations = {};
      }
    }

    _instance = PlantFrameService._(
      extractor ?? const VideoThumbnailExtractor(),
      root,
      durations,
      durFile,
    );
    return _instance!;
  }

  // -------------------------------------------------------------------------
  // 注册本地视频（启动时由 ResourceDownloader 调用）
  // -------------------------------------------------------------------------

  void registerVideos(Map<String, String> paths) => _videoPaths.addAll(paths);

  String? localVideo(String plantId) => _videoPaths[plantId];

  // -------------------------------------------------------------------------
  // 视频时长：JSON 没填就运行时探测一次，并持久化
  // -------------------------------------------------------------------------

  /// 时长缓存 key。带上 url 摘要，视频替换后旧时长自动失效。
  String _durationKey(PlantSpecies plant) => '${plant.id}_${_urlTag(plant)}';

  Future<int> durationFor(PlantSpecies plant) async {
    final preset = plant.videoDurationMs;
    if (preset != null && preset > 0) return preset;

    final key = _durationKey(plant);
    final cached = _durations[key];
    if (cached != null) return cached;

    final path = _videoPaths[plant.id];
    if (path == null) throw StateError('视频未注册: ${plant.id}');

    final vc = VideoPlayerController.file(File(path));
    try {
      await vc.initialize();
      final ms = vc.value.duration.inMilliseconds;
      if (ms <= 0) throw StateError('时长探测失败: ${plant.id}');
      _durations[key] = ms;
      unawaited(_persistDurations());
      return ms;
    } finally {
      await vc.dispose(); // 只为拿时长，用完立刻释放解码器
    }
  }

  Future<void> _persistDurations() async {
    try {
      await _durationsFile.writeAsString(json.encode(_durations));
    } catch (_) {}
  }

  /// 启动后后台预热所有视频时长，消灭首次进入的等待
  Future<void> warmUpDurations(List<PlantSpecies> plants) async {
    for (final p in plants) {
      if (p.videoDurationMs != null) continue;
      if (_durations.containsKey(_durationKey(p))) continue;
      try {
        await durationFor(p);
      } catch (_) {}
    }
  }

  // -------------------------------------------------------------------------
  // 核心：取第 day 天的帧
  // -------------------------------------------------------------------------

  String _framePath(PlantSpecies plant, int frameIndex) =>
      p.join(_root.path, '${plant.id}_${_urlTag(plant)}_f$frameIndex.jpg');

  /// 视频 URL 变化时让旧帧缓存自动失效（防止视频替换后画面不更新）
  String _urlTag(PlantSpecies plant) => _djb2(plant.videoUrl).toRadixString(36);

  static int _djb2(String s) {
    var h = 5381;
    for (final unit in s.codeUnits) {
      h = ((h << 5) + h + unit) & 0x7FFFFFFF;
    }
    return h;
  }

  /// 同步命中判断 —— 微秒级。绝大多数点击走这条路径，零抽帧、零等待。
  String? peek(PlantSpecies plant, int day) {
    final path = _framePath(plant, plant.frameIndexForDay(day));
    return File(path).existsSync() ? path : null;
  }

  Future<String?> frameFor(PlantSpecies plant, int day) async {
    final idx = plant.frameIndexForDay(day);
    final out = _framePath(plant, idx);

    // L1: 磁盘命中（同步判断，极快）
    if (File(out).existsSync()) return out;

    // L2: 合并同 key 的并发请求
    final pending = _inflight[out];
    if (pending != null) return pending;

    final future = _gate.run(() async {
      final video = _videoPaths[plant.id];
      if (video == null) return null;

      final durationMs = await durationFor(plant);
      final result = await _extractor.extract(
        videoFile: video,
        outputFile: out,
        timeMs: plant.timeMsForDay(day, durationMs),
        maxWidth: plant.frameWidth,
      );

      // 抽帧可能返回 null（视频损坏 / seek 失败），清理 0 字节残file
      final f = File(out);
      if (result == null || !f.existsSync() || f.lengthSync() == 0) {
        if (f.existsSync()) f.deleteSync();
        return null;
      }
      return out;
    });

    _inflight[out] = future;
    try {
      return await future;
    } finally {
      _inflight.remove(out);
    }
  }

  // -------------------------------------------------------------------------
  // 预取
  // -------------------------------------------------------------------------

  /// 后台静默抽好后续 N 天。用户看第 N 天时，第 N+1 天已在磁盘上。
  void prefetch(PlantSpecies plant, int currentDay, {int ahead = 4}) {
    final end = (currentDay + ahead).clamp(1, plant.totalDays);
    for (var d = currentDay + 1; d <= end; d++) {
      if (peek(plant, d) != null) continue;
      unawaited(frameFor(plant, d));
    }
  }

  /// 进入植物页时：先把第 1 天和成熟帧准备好
  Future<void> warmUp(PlantSpecies plant) async {
    await Future.wait([
      frameFor(plant, 1),
      frameFor(plant, plant.totalDays),
    ]);
  }

  // -------------------------------------------------------------------------
  // 缓存管理
  // -------------------------------------------------------------------------

  Future<int> clearFrames() async {
    var n = 0;
    for (final f in _root.listSync().whereType<File>()) {
      if (p.basename(f.path).endsWith('.jpg')) {
        f.deleteSync();
        n++;
      }
    }
    return n;
  }

  Future<int> cacheSizeBytes() async {
    var total = 0;
    for (final f in _root.listSync().whereType<File>()) {
      total += await f.length();
    }
    return total;
  }
}
